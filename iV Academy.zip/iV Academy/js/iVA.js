(function ($) {

  // Handle click on toggle search button
  $('#toggle-search').click(function () {
    $('#search-form, #toggle-search').toggleClass('open');
    return false;
  });

  // Handle click on search submit button
  $('#search-form input[type=submit]').click(function () {
    $('#search-form, #toggle-search').toggleClass('open');
    return true;
  });

  // Clicking outside the search form closes it
  $(document).click(function (event) {
    var target = $(event.target);

    if (!target.is('#toggle-search') && !target.closest('#search-form').size()) {
      $('#search-form, #toggle-search').removeClass('open');
    }
  });
  $(".hamburger").click(function () {
    $(this).toggleClass("is-active");
  });
  $('a').click(function () {
    $('html, body').animate({
      scrollTop: $($(this).attr('href')).offset().top
    }, 500);
    return false;
  });
  $("a[href='#top']").click(function () {
    $("html, body").animate({
      scrollTop: 0
    }, "slow");
    return false;
  });

})(jQuery); // JavaScript Document

$(document).scroll(function () {
  var $nav = $(".fixed-top");
  $nav.toggleClass('scrolled', $(this).scrollTop() > $nav.height());
});
$(document).ready(function () {
  $("#list-item").owlCarousel({
    loop: true,
    autoplay: true,
    autoplayTimeout: 2000,
    autoplayHoverPause: true,
    paginationSpeed: 500,
    singleItem: true,
    margin: 20,
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 3,
        nav: true
      },
      1000: {
        items: 2,
        nav: true,
        loop: true,
        dots: true,
        navText: ["", ""],
        rewindNav: true
      },
      1400: {
        items: 3,
        nav: true,
        loop: true,
        dots: true,
        navText: ["", ""],
        rewindNav: true
      }
    }
  });
  $("#customers-testimonials").owlCarousel({
    autoplay: true,
    autoplayTimeout: 2000,
    autoplayHoverPause: true,
    paginationSpeed: 500,
    singleItem: true,
    items: 1,
    stagePadding: 10,
    center: true,
    nav: true,
    margin: 0,
    dots: true,
    navText: ["", ""],
    loop: true,
    responsive: {
      0: {
        items: 1
      },
      768: {
        items: 3
      },
      1170: {
        items: 3
      }

    }
  });


});

$(document).ready(function () {

  $(".filter-button").click(function () {
    var value = $(this).attr('data-filter');

    if (value == "all") {

      //$('.filter').removeClass('hidden');
      $('.filter').show('1000');
      $('.courses-content').hide('1000');
      $('.form-advanced').hide('1000');
    } else {
      //            $('.filter[filter-item="'+value+'"]').removeClass('hidden');
      //            $(".filter").not('.filter[filter-item="'+value+'"]').addClass('hidden');
      $(".filter").not('.' + value).hide('3000');
      $('.filter').filter('.' + value).show('3000');

    }
  });

  if ($(".filter-button").removeClass("active")) {
    $(this).removeClass("active");
  }
  $(this).addClass("active");

});


var swiper = new Swiper(".mySwiper", {
  direction: "vertical",
  slidesPerView: 2,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});

$('.carousel').carousel({
  interval: 2000
})
